package com.example.kezel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
